CREDITS TO WENTAT'S GUIDANCE FOR THE FLASK IMPLEMENTATION: https://github.com/Lumotheninja/

Instructions:
1) Run app.py on command prompt
2) Copy and paste the link given into a web browser to run