from flask import Flask, render_template, request, send_from_directory
import torchvision.models as models
import torchvision.transforms as transforms
import torch
import numpy as np
import os
from PIL import Image
import time

classes = ['normal','tumor']
clf_model = models.inception_v3(pretrained = True)
clf_model.fc = torch.nn.Linear(2048,2)

app = Flask(__name__)

def upload(image, classes, model):
    model.eval()
    img = Image.open(image)
    img.save('./static/images/user_image.png')
    transform = transforms.Compose([transforms.Resize(size=96),
                                transforms.FiveCrop(96),
                                transforms.Lambda(lambda crops: torch.stack([transforms.ToTensor()(crop) for crop in crops]
                                                                            + [transforms.ToTensor()(transforms.functional.adjust_brightness(crop, 1.5)) for crop in crops])),
                                transforms.Lambda(lambda crops:
                                                  torch.stack([transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])(crop) for crop in crops]))])
    data = transform(img).unsqueeze(dim=0) #creates batch of 1
    bs, ncrops, c, h, w = data.size()
    output = model(data.view(-1, c, h, w))
    output = output.view(bs, ncrops, -1).mean(1)
    sigmoid = torch.sigmoid(output)
    index = output.argmax()
    return (classes[index])

@app.route('/', methods=['GET', 'POST'])
def index():
    results = None
    user_image=None
    message=None
    error = None
    if request.method == 'GET':
        return render_template('index.html', results=results, user_image=user_image, message=message)
    if request.method == 'POST':
        image = request.files['image']
        try: 
            label = upload(image, classes, clf_model)
            message = 'The image is classified as ' + label
            user_image = '/static/images/user_image.png?' + str(time.time())
            results = '/static/images/sigmoid.png?' + str(time.time())
        except Exception as e:
            message = str(e)
        return render_template('index.html', results=results, user_image=user_image, message=message)

if __name__ == '__main__':    
    app.run(debug=True)
